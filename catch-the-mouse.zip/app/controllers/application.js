'use strict';
import Controller from '@ember/controller';

export default Controller.extend({
  
})
